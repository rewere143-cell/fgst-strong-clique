# Explicit elementary C5 stability

Status: independently audited, including exact rational constant checks. See `../audit/stability_proof_audit.md` and `../audit/verify_stability_constants.py`. Unlike the preceding qualitative and polynomial-removal arguments, this proof uses no graph removal lemma. It uses only the audited positive local-defect penalty and elementary graph counting.

## Theorem

Let G be a finite simple graph with maximum degree Δ>0, and let H be a strong clique with

m=|E(H)|≥(5/4−δ)Δ², where 0<δ≤10^(−24).

There are five pairwise disjoint sets U_0,...,U_4 such that, for t=δ^(1/4) and for the complete C5 blowup B on these parts,

1. ||U_i|−Δ/2|≤100000tΔ for each i.
2. |E(H) symmetric_difference E(B)|≤100000tΔ².
3. For U=U_0∪...∪U_4, |E(G[U]) symmetric_difference E(B)|≤100000tΔ².
4. |E_G(U,V(G)\U)|≤100000tΔ².

All indices of the five parts are cyclic. The constants are deliberately conservative.

## Input from the exact certificate

Either independently verified sharp certificate gives the following two bounds:

m≤(5/4)Δ²,

S+6t(H)≤640δΔ³, where S=Σ_v d_H(v)(Δ−d_H(v)).   (1)

Indeed, the compact certificate has a common local-defect coefficient exceeding 1/255, giving S+6t(H)≤(1275/2)δΔ³<640δΔ³. The preserved baseline certificate is stronger. Here t(H) denotes the number of unordered all-marked triangles; the scalar t=δ^(1/4) is different notation and will always appear without the argument H.

## Lemma 1: almost-regular bipartite marked cliques

Suppose K is a bipartite strong clique in G, has at most 3Δ vertices, and has minimum degree at least(1−ε)Δ on its vertex set, where 0≤ε≤1/8. Then

e(K)≤(1+8ε)Δ².   (2)

Proof. Let X,Y be the bipartition and fix x∈X. Put A=N_K(x), B=Y\N_G(x), and E=X∩N_G(x). Since x has at least(1−ε)Δ marked neighbors, |E|≤εΔ. Consider x'∈X\E with a K-neighbor y∈B. For every a∈A, the disjoint marked edges xa and x'y must be joined by a G-cross-edge. The pairs xx' and xy are not G-edges, so either ax' or ay must be a G-edge. As K is bipartite, every G-edge from y to A⊂Y is unmarked, and there are at most Δ−d_K(y)≤εΔ of them. Hence x' has at least |A|−εΔ≥(1−2ε)Δ G-neighbors in A, leaving room for at most 2εΔ K-neighbors in B.

Summing K-degrees into B over X therefore gives

e_K(X,B)≤|E|Δ+2εΔ|X|≤7εΔ².

On the other hand every y∈B has K-degree at least(1−ε)Δ. Thus |B|≤7εΔ/(1−ε)≤8εΔ. Since Y\B⊂N_G(x), we have |Y|≤(1+8ε)Δ, and e(K)≤|Y|Δ proves (2). □

## Lemma 2: a short odd cycle

A triangle-free nonbipartite graph K of minimum degree d and order n has an induced odd cycle of length r satisfying rd≤2n.

Proof. Take a shortest odd cycle C, of length r. It is induced. Every vertex outside C has at most two neighbors on C. Otherwise the cyclic gaps between its consecutive cycle neighbors are all at least two by triangle-freeness. Since their sum r is odd, one gap is odd; the other at least two gaps have total length at least four. That odd gap, together with two edges to the outside vertex, gives a shorter odd cycle. Vertices on C have exactly two neighbors on C. Summing the degrees of C therefore yields rd≤Σ_(v∈C)d_K(v)≤2n. □

## Step 1: obtain a high-minimum-degree core

Let h_v=d_H(v), let t=δ^(1/4)≤10^(−6), and put

V={v:h_v≥(1−t²)Δ},  J=H[V].

By (1), deleting the other nonisolated H-vertices discards at most 640t²Δ² marked edges. Consequently

e(J)≥(5/4−641t²)Δ².   (3)

Also

|V|≤2m/[(1−t²)Δ]≤(5/2+5t²)Δ.   (4)

Combining (3) and(4),

Σ_(v∈V)[Δ−d_J(v)]≤1287t²Δ².   (5)

Delete the vertices Z_1={v∈V:d_J(v)<(1−t)Δ}. Equation (5) gives |Z_1|≤1287tΔ. The remaining graph J_1 has minimum degree at least(1−1288t)Δ and order at most(5/2+5t²)Δ.

## Step 2: delete the triangles at low edge cost

The graph J_1 has at most t(H)≤107t⁴Δ³ triangles. Call an edge popular if its endpoints have at least Δ/7 common neighbors in J_1.

Every triangle contains a popular edge. Indeed, for its three vertex-neighborhoods A_1,A_2,A_3,

Σ_(i<j)|A_i∩A_j|≥Σ_i|A_i|−|V(J_1)|
≥(1/2−3864t−5t²)Δ.

For t≤10^(−6), one of the three pair intersections therefore exceeds Δ/7. Delete all popular edges. There are at most

21t(H)/Δ≤2247t⁴Δ²   (6)

of them, because each lies in at least Δ/7 triangles and each triangle has three edges. The resulting graph J_2 is triangle-free.

Let ℓ_v=d_(J_1)(v)−d_(J_2)(v), and delete Z_2={v:ℓ_v>tΔ}. By (6), |Z_2|≤4494t³Δ. The graph

K=J_2[V(J_2)\Z_2]

is a triangle-free marked strong clique in G, with

- minimum degree at least(1−1290t)Δ;
- order at most(5/2+5t²)Δ≤3Δ;
- e(K)≥(5/4−1290t)Δ²;
- |E(H)\E(K)|≤1290tΔ².

For the last two estimates, the total marked edges removed are at most

[640t²+1287t+2247t⁴+4494t³]Δ²≤1288tΔ²,

and m≥(5/4−t⁴)Δ². The conservative constant 1290 covers both bounds.

## Step 3: find an induced C5

The graph K cannot be bipartite. Otherwise Lemma 1 with ε=1290t≤1/8 would give e(K)≤(1+10320t)Δ², contradicting e(K)≥(5/4−1290t)Δ² when t≤10^(−6).

By Lemma 2, its shortest odd cycle has length r with

r≤(5+10t²)/(1−1290t)<7.

It is therefore an induced C5. Label it c_0,...,c_4 cyclically.

## Step 4: use the cycle to form five parts

Every vertex of K has at most two neighbors on C5, and two such neighbors must be nonadjacent. Let Z be the set with at most one cycle neighbor. Summing the five cycle-vertex degrees gives

|Z|≤2|V(K)|−Σ_i d_K(c_i)
≤(6450t+10t²)Δ≤6451tΔ.   (7)

Partition V(K)\Z into U_i according to cycle neighborhood {c_(i−1),c_(i+1)}. Each U_i is nonempty because it contains c_i. Triangle-freeness forbids edges within a part or between nonconsecutive parts, since such vertices have a common cycle neighbor.

Let a_i=|U_i| and b_i=a_(i−1)+a_(i+1). The cycle vertex c_i has degree at least(1−1290t)Δ, so(7) implies

b_i≥(1−7741t)Δ.

Also Σ_i b_i=2Σ_i a_i≤(5+10t²)Δ. Using the preceding lower bounds for the other four b_j gives

b_i≤(1+30965t)Δ.

Thus |b_i−Δ|≤30965tΔ for every i. Inverting this five-cycle linear system, for example by

a_0−Δ/2=[(b_0−Δ)+(b_1−Δ)−(b_2−Δ)−(b_3−Δ)+(b_4−Δ)]/2,

we obtain

|a_i−Δ/2|≤77413tΔ.   (8)

## Step 5: count the edge edits and the host cut

Let U be the union of the five parts and let B be their complete C5 blowup. We have K[U]⊂B. Moreover,

e(B)=(1/2)Σ_i a_i b_i
≤(1/2)(5/2+5t²)(1+30965t)Δ²
≤(5/4+40000t)Δ².

By (7),

e(K[U])≥e(K)−|Z|Δ≥(5/4−7741t)Δ².

Therefore B is missing at most 47741tΔ² edges from K[U]. Adding the at most 1290tΔ² marked edges lost in producing K and the at most 6451tΔ² K-edges incident to Z gives

|E(H) symmetric_difference E(B)|≤55482tΔ².   (9)

Since G[U] has at most |U|Δ/2 edges,

|E(G[U])\E(K[U])|≤|U|Δ/2−e(K[U])≤7742tΔ².

Together with the missing-edge bound, this gives

|E(G[U]) symmetric_difference E(B)|≤55483tΔ².   (10)

Finally,

|E_G(U,V(G)\U)|≤|U|Δ−2e(G[U])
≤|U|Δ−2e(K[U])≤15484tΔ².   (11)

Equations (8)–(11) imply all four conclusions with constant 100000. □

## Provenance and scope

The popular-edge observation in Step 2 is the elementary mechanism behind the high-minimum-degree triangle removal argument of Fox and Wigderson, *Minimum degree and the graph removal lemma*, J.Graph Theory 102 (2023),648–665, https://arxiv.org/abs/2105.09194. The entire needed argument is included above, so no quantitative removal theorem is invoked.

The statement applies to arbitrary ambient G and arbitrary strong clique H; no additional graph-class assumptions occur in the conclusion. The tiny δ threshold and large constant are proof conveniences, not optimized values.
