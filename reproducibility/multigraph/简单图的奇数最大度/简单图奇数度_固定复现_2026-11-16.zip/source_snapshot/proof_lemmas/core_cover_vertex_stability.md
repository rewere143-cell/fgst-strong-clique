# Vertex-count stability from a dense C5 core

Status: independently audited elementary corollary. It supplements the linear edge/part/cut stability theorem.

## A weighted C5 inequality

For any A>0 and numbers 0≤x_i≤A, indexed modulo five,

Σ_i x_i x_(i+1)≥A(Σ_i x_i−2A).   (1)

After dividing by A², the difference is a multi-affine polynomial on[0,1]^5. Its minimum is attained at a cube vertex. There it equals e(C5[S])−|S|+2, which is nonnegative for every vertex subset S of C5. This proves(1).

## Cover size of a nearly complete C5 core

Suppose U is partitioned into five parts of size at most A, and H[U] omits at most M edges of the complete consecutive-part C5 blowup. If I is H-independent, let x_i=|I∩U_i|. All consecutive-part pairs selected by I are missing marked edges, so Σx_i x_(i+1)≤M. Equation (1) gives

α(H[U])≤2A+M/A,

and therefore

τ(H[U])≥|U|−2A−M/A.   (2)

Extra marked edges inside or across nonconsecutive parts only strengthen this bound.

## Every outside marked vertex spends many host edges on the core

Let x∉U have positive H-degree, and choose xy∈H. The set

[N_G(x)∪N_G(y)∪{y}]∩U

covers H[U]. Indeed, any marked core edge disjoint from xy must have a cross witness to xy; a core edge incident with y is covered by y. Thus

d_G(x,U)≥τ(H[U])−Δ−1.   (3)

If the right side is positive, summing(3) over outside marked vertices bounds their number by

|V(H)\U|≤ |E_G(U,V(G)\U)|/[τ(H[U])−Δ−1],   (4)

where V(H) denotes only vertices of positive H-degree.

## Applying the linear stability theorem

Take U specifically from the constructed K-core in the linear stability proof. Then U⊂V(H), where V(H) consists only of marked nonisolated vertices. Use the constants C=10^9 and δ≤10^(−28). The five parts satisfy

|U|≥(5/2−5Cδ)Δ,
A:=max_i|U_i|≤(1/2+Cδ)Δ,
A≥(1/2−Cδ)Δ,
M≤CδΔ².

Since Cδ≤10^(−19), equation(2) yields

τ(H[U])≥(3/2−10Cδ)Δ.

For Δ≥4, this makes τ(H[U])−Δ−1≥Δ/5. Combining(4) with the linear host-cut bound gives

|V(H)\U|≤5CδΔ=5·10^9δΔ.   (5)

The remaining small degrees cause no exception. For Δ=1 or 3, the integer gap below 5Δ²/4 precludes the near-extremal hypothesis with this δ. For Δ=2, the hypothesis forces exact equality, whose marked graph is C5, so the outside set is empty; the linear part-size error is below 1/2, forcing each part to be a singleton. (Δ=0 is excluded.)

In particular the entire marked support, not merely its high-degree core, satisfies

||V(H)|−(5/2)Δ|≤10CδΔ=10^10δΔ.

Thus almost all marked vertices themselves belong to the five C5 parts, with a linear bound on the number of exceptions. □
